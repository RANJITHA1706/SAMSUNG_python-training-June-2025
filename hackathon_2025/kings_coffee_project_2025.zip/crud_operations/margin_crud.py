import pandas as pd
import os

data_path = 'kings_coffee_data/ingredient_prices.csv'

def load_data():
    return pd.read_csv(data_path) if os.path.exists(data_path) else pd.DataFrame(columns=['item', 'supplier', 'cost_price', 'selling_price', 'last_updated'])

def save_data(df):
    df.to_csv(data_path, index=False)

def view_margins():
    df = load_data()
    print(df)

def add_margin():
    df = load_data()
    new_entry = {
        'item': input("Item Name: "),
        'supplier': input("Supplier: "),
        'cost_price': float(input("Cost Price (₹): ")),
        'selling_price': float(input("Selling Price (₹): ")),
        'last_updated': input("Last Updated (YYYY-MM-DD): ")
    }
    df = pd.concat([df, pd.DataFrame([new_entry])], ignore_index=True)
    save_data(df)
    print("Margin record added.")

def update_margin():
    df = load_data()
    item = input("Enter item name to update: ")
    if item in df['item'].values:
        df.loc[df['item'] == item, 'supplier'] = input("New Supplier: ")
        df.loc[df['item'] == item, 'cost_price'] = float(input("New Cost Price: "))
        df.loc[df['item'] == item, 'selling_price'] = float(input("New Selling Price: "))
        df.loc[df['item'] == item, 'last_updated'] = input("New Last Updated (YYYY-MM-DD): ")
        save_data(df)
        print("Margin record updated.")
    else:
        print("Item not found.")

def delete_margin():
    df = load_data()
    item = input("Enter item name to delete: ")
    if item in df['item'].values:
        df = df[df['item'] != item]
        save_data(df)
        print("Margin record deleted.")
    else:
        print("Item not found.")

def margin_menu():
    while True:
        print("\n--- Margin Data CRUD Menu ---")
        print("1. View Margin Data")
        print("2. Add Margin Record")
        print("3. Update Margin Record")
        print("4. Delete Margin Record")
        print("0. Back to Main Menu")
        choice = input("Choose an option: ")
        if choice == '1':
            view_margins()
        elif choice == '2':
            add_margin()
        elif choice == '3':
            update_margin()
        elif choice == '4':
            delete_margin()
        elif choice == '0':
            break
        else:
            print("Invalid choice.")
