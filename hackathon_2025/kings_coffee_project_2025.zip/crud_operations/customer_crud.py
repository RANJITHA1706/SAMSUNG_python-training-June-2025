import pandas as pd
import os

def customer_menu():
    file_path = "kings_coffee_data/customer_data.csv"

    if not os.path.exists(file_path):
        pd.DataFrame(columns=["customer_id", "visit_date", "amount"]).to_csv(file_path, index=False)

    while True:
        print("\n--- Customer Data CRUD Menu ---")
        print("1. View Customers")
        print("2. Add Customer")
        print("3. Update Customer")
        print("4. Delete Customer")
        print("0. Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            df = pd.read_csv(file_path)
            print(df if not df.empty else "No customer records found.")

        elif choice == "2":
            customer_id = input("Enter customer ID: ")
            visit_date = input("Enter visit date (YYYY-MM-DD): ")
            amount = float(input("Enter amount spent: "))

            df = pd.read_csv(file_path)

            new_row = {
                "customer_id": customer_id,
                "visit_date": visit_date,
                "amount": amount
            }

            df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)
            df.to_csv(file_path, index=False)
            print("Customer added successfully.")

        elif choice == "3":
            customer_id = input("Enter customer ID to update: ")
            df = pd.read_csv(file_path)
            idx = df[df['customer_id'] == customer_id].index

            if not idx.empty:
                visit_date = input("Enter new visit date (YYYY-MM-DD): ")
                amount = float(input("Enter new amount spent: "))

                df.loc[idx, 'visit_date'] = visit_date
                df.loc[idx, 'amount'] = amount

                df.to_csv(file_path, index=False)
                print("Customer updated successfully.")
            else:
                print("Customer ID not found.")

        elif choice == "4":
            customer_id = input("Enter customer ID to delete: ")
            df = pd.read_csv(file_path)
            df = df[df['customer_id'] != customer_id]
            df.to_csv(file_path, index=False)
            print("Customer deleted (if existed).")

        elif choice == "0":
            break

        else:
            print("Invalid choice.")
