import pandas as pd
import os

INVENTORY_FILE = 'kings_coffee_data/inventory_status.csv'

def load_inventory():
    if os.path.exists(INVENTORY_FILE):
        return pd.read_csv(INVENTORY_FILE)
    else:
        return pd.DataFrame(columns=["item", "quantity", "daily_usage", "expiry_date", "restock_date"])

def save_inventory(df):
    df.to_csv(INVENTORY_FILE, index=False)

def view_inventory():
    df = load_inventory()
    if df.empty:
        print("Inventory is empty.")
    else:
        print("\n Current Inventory:\n")
        print(df)

def add_item():
    df = load_inventory()
    item = input("Enter item name: ")
    quantity = float(input("Enter quantity: "))
    daily_usage = float(input("Enter daily usage: "))
    expiry = input("Enter expiry date (YYYY-MM-DD): ")
    restock = input("Enter restock date (YYYY-MM-DD): ")

    new_row = {
        "item": item,
        "quantity": quantity,
        "daily_usage": daily_usage,
        "expiry_date": expiry,
        "restock_date": restock
    }
    df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)
    save_inventory(df)
    print(f"'{item}' added successfully.")

def update_item():
    df = load_inventory()
    item = input("Enter the item name to update: ")
    if item not in df['item'].values:
        print(" Item not found.")
        return
    print("Leave blank to skip update for a field.")
    quantity = input("New quantity: ")
    daily_usage = input("New daily usage: ")
    expiry = input("New expiry date (YYYY-MM-DD): ")
    restock = input("New restock date (YYYY-MM-DD): ")

    idx = df[df['item'] == item].index[0]
    if quantity: df.at[idx, 'quantity'] = float(quantity)
    if daily_usage: df.at[idx, 'daily_usage'] = float(daily_usage)
    if expiry: df.at[idx, 'expiry_date'] = expiry
    if restock: df.at[idx, 'restock_date'] = restock

    save_inventory(df)
    print(f"'{item}' updated successfully.")

def delete_item():
    df = load_inventory()
    item = input("Enter the item name to delete: ")
    if item not in df['item'].values:
        print(" Item not found.")
        return
    df = df[df['item'] != item]
    save_inventory(df)
    print(f" '{item}' deleted successfully.")

def inventory_menu():
    while True:
        print("\n Inventory CRUD Menu:")
        print("1. View Inventory")
        print("2. Add Item")
        print("3. Update Item")
        print("4. Delete Item")
        print("0. Back to Main Menu")

        choice = input("Enter your choice: ")
        if choice == '1':
            view_inventory()
        elif choice == '2':
            add_item()
        elif choice == '3':
            update_item()
        elif choice == '4':
            delete_item()
        elif choice == '0':
            break
        else:
            print("Invalid input. Try again.")
