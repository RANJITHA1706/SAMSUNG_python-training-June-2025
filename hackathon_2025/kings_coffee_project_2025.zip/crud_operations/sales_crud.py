import pandas as pd
import os

def sales_menu():
    file_path = 'kings_coffee_data/coffee_sales.csv'

    while True:
        print("\n--- Sales CRUD Menu ---")
        print("1. View all sales records")
        print("2. Add a new sale")
        print("3. Delete a sale by ID")
        print("4. Exit")
        choice = input("Enter your choice: ")

        if choice == "1":
            df = pd.read_csv(file_path)
            print(df)

        elif choice == "2":
            date = input("Enter sale date (YYYY-MM-DD): ")
            item = input("Enter item name: ")
            size = input("Enter cup size: ")
            quantity = int(input("Enter quantity: "))
            price = float(input("Enter price: "))
            new_id = input("Enter sale ID: ")
            cust_id = input("Enter customer ID: ")

            # Create new row to match your CSV order
            new_row = {
                "date": date,
                "item": item,
                "size": size,
                "quantity": quantity,
                "total_price": price,
                "id": new_id,
                "customer_id": cust_id
            }

            # Load and append
            df = pd.read_csv(file_path)
            df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)

            # Reorder columns to your original order before saving
            desired_order = ["date", "item", "size", "quantity", "total_price", "id", "customer_id"]
            df = df[desired_order]

            df.to_csv(file_path, index=False)
            print("Sale added successfully.")

        elif choice == "3":
            sale_id = input("Enter sale ID to delete: ")
            df = pd.read_csv(file_path)
            df = df[df["id"] != sale_id]
            df.to_csv(file_path, index=False)
            print("Sale deleted.")

        elif choice == "4":
            break

        else:
            print("Invalid choice.")
