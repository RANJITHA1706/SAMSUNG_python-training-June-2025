import sys
import os

# Allow module imports from parent directories
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from crud_operations.inventory_crud import inventory_menu
from crud_operations.sales_crud import sales_menu
from crud_operations.customer_crud import customer_menu
from crud_operations.margin_crud import margin_menu

def run():
    while True:
        print("\nCRUD Operations Menu:")
        print("1. Inventory CRUD")
        print("2. Sales CRUD")
        print("3. Customer CRUD")
        print("4. Margin/Price CRUD")
        print("0. Exit")

        choice = input("Select an option: ").strip()

        if choice == '1':
            inventory_menu()
        elif choice == '2':
            sales_menu()
        elif choice == '3':
            customer_menu()
        elif choice == '4':
            margin_menu()
        elif choice == '0':
            print("Exiting CRUD Console.")
            break
        else:
            print("Invalid option. Please try again.")

# Only run directly for testing
if __name__ == "__main__":
    run()
