import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import os
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from analysis_modules.customer_behaviour import CustomerBehavior

def run():
    print("\nRunning: Customer Behavior Analysis")
    data_path = os.path.join("kings_coffee_data", "customer_data.csv")
    behavior = CustomerBehavior(data_path)

    returning_customers = behavior.get_returning_customers()
    print("\nReturning Customers:\n", returning_customers.head())

    top_spenders = behavior.get_top_spenders()
    print("\nTop 10 Spenders:\n", top_spenders)

    visit_freq = behavior.get_visit_frequency()
    print("\nMonthly Visit Frequency:\n", visit_freq)

    plt.figure(figsize=(8, 5))
    sns.barplot(x=visit_freq.index.astype(str), y=visit_freq.values, palette='coolwarm')
    plt.title("Monthly Visit Frequency")
    plt.xlabel("Month")
    plt.ylabel("Number of Visits")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    run()
