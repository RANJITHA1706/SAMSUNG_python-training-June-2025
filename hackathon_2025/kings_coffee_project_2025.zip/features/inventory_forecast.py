def run():
    import pandas as pd
    import matplotlib
    matplotlib.use('TkAgg')
    import matplotlib.pyplot as plt
    import seaborn as sns
    import os
    import sys

    sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
    from analysis_modules.inventory_manager import InventoryManager

    # Paths
    data_path = 'kings_coffee_data/inventory_status.csv'
    visuals_path = 'screenshots_plots/'
    outputs_path = 'csv_outputs/'

    os.makedirs(visuals_path, exist_ok=True)
    os.makedirs(outputs_path, exist_ok=True)

    manager = InventoryManager(data_path)

    # Inventory Forecast (Low Stock)
    forecast_df = manager.get_inventory_forecast()
    print("\nInventory Forecast")
    print(forecast_df)

    forecast_file = f"{outputs_path}inventory_forecast.csv"
    if not os.path.exists(forecast_file):
        forecast_df.to_csv(forecast_file, index=False)
        print(f"Saved: {forecast_file}")
    else:
        print(f"Skipped: {forecast_file} already exists.")

    forecast_plot = f"{visuals_path}inventory_forecast.png"
    plt.figure(figsize=(12, 5))
    sns.barplot(x=forecast_df["Ingredient"], y=forecast_df["CurrentStock"], palette="flare")
    plt.title("Low Stock Inventory Forecast")
    plt.xlabel("Ingredient")
    plt.ylabel("Current Stock")
    plt.xticks(rotation=45, ha='right')
    plt.tight_layout()
    if not os.path.exists(forecast_plot):
        plt.savefig(forecast_plot)
        print(f"Saved plot: {forecast_plot}")
    else:
        print(f"Skipped plot: {forecast_plot} already exists.")
    plt.show()
    plt.close()

    # Weekly Forecast (Expiring Soon)
    weekly_forecast = manager.get_weekly_forecast()
    print("\nWeekly Inventory Forecast")
    print(weekly_forecast)

    weekly_file = f"{outputs_path}weekly_inventory_forecast.csv"
    if not os.path.exists(weekly_file):
        weekly_forecast.to_csv(weekly_file, index=False)
        print(f"Saved: {weekly_file}")
    else:
        print(f"Skipped: {weekly_file} already exists.")

    weekly_plot = f"{visuals_path}weekly_inventory_forecast.png"
    plt.figure(figsize=(12, 5))
    sns.barplot(x=weekly_forecast["Ingredient"], y=weekly_forecast["CurrentStock"], palette="crest")
    plt.title("Items Expiring Within 7 Days")
    plt.xlabel("Ingredient")
    plt.ylabel("Current Stock")
    plt.xticks(rotation=45, ha='right')
    plt.tight_layout()
    if not os.path.exists(weekly_plot):
        plt.savefig(weekly_plot)
        print(f"Saved plot: {weekly_plot}")
    else:
        print(f"Skipped plot: {weekly_plot} already exists.")
    plt.show()
    plt.close()

    # At-Risk Ingredients
    at_risk_df = manager.get_at_risk_ingredients()
    if not at_risk_df.empty:
        print("\nAt-Risk Ingredients")
        print(at_risk_df)

        at_risk_file = f"{outputs_path}at_risk_ingredients.csv"
        if not os.path.exists(at_risk_file):
            at_risk_df.to_csv(at_risk_file, index=False)
            print(f"Saved: {at_risk_file}")
        else:
            print(f"Skipped: {at_risk_file} already exists.")

        at_risk_plot = f"{visuals_path}at_risk_ingredients.png"
        plt.figure(figsize=(12, 5))
        sns.barplot(x=at_risk_df["Ingredient"], y=at_risk_df["CurrentStock"], palette="rocket")
        plt.title("At-Risk Ingredients (Low Stock + Expiring Soon)")
        plt.xlabel("Ingredient")
        plt.ylabel("Stock Remaining")
        plt.xticks(rotation=45, ha='right')
        plt.tight_layout()
        if not os.path.exists(at_risk_plot):
            plt.savefig(at_risk_plot)
            print(f"Saved plot: {at_risk_plot}")
        else:
            print(f"Skipped plot: {at_risk_plot} already exists.")
        plt.show()
        plt.close()
    else:
        print("\nNo at-risk ingredients found.")

if __name__ == "__main__":
    run()
