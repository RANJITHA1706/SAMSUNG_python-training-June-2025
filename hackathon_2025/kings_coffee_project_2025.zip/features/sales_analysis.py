def run():
    import pandas as pd
    import matplotlib
    matplotlib.use('TkAgg')
    import matplotlib.pyplot as plt
    import seaborn as sns
    import os
    import sys

    sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
    from analysis_modules.sales_analyzer import SalesAnalyzer

    data_path = 'kings_coffee_data/coffee_sales.csv'
    visuals_path = 'screenshots_plots/'
    outputs_path = 'csv_outputs/'

    os.makedirs(visuals_path, exist_ok=True)
    os.makedirs(outputs_path, exist_ok=True)

    analyzer = SalesAnalyzer(data_path)

    # Monthly Sales
    monthly_sales = analyzer.get_monthly_sales()
    print("\nMONTHLY SALES SUMMARY")
    print(monthly_sales)

    monthly_csv = f"{outputs_path}monthly_sales_summary.csv"
    if not os.path.exists(monthly_csv):
        monthly_sales.to_csv(monthly_csv)
        print(f"Saved: {monthly_csv}")
    else:
        print(f"Skipped: {monthly_csv} already exists.")

    monthly_plot = f"{visuals_path}sales_trends.png"
    plt.figure(figsize=(10, 5))
    sns.barplot(x=monthly_sales.index, y=monthly_sales.values, palette="crest")
    plt.title("Monthly Coffee Sales (₹)")
    plt.xlabel("Month")
    plt.ylabel("Total Sales")
    plt.tight_layout()
    if not os.path.exists(monthly_plot):
        plt.savefig(monthly_plot)
        print(f"Saved plot: {monthly_plot}")
    else:
        print(f"Skipped plot: {monthly_plot} already exists.")
    plt.show()
    plt.close()

    # Top Items
    top_items = analyzer.get_top_selling_items()
    print("\nTOP 5 SELLING ITEMS")
    print(top_items)

    top_csv = f"{outputs_path}top_items.csv"
    if not os.path.exists(top_csv):
        top_items.to_csv(top_csv)
        print(f"Saved: {top_csv}")
    else:
        print(f"Skipped: {top_csv} already exists.")

    top_plot = f"{visuals_path}top_selling_items.png"
    plt.figure(figsize=(8, 4))
    sns.barplot(x=top_items.values, y=top_items.index, palette="magma")
    plt.title("Top 5 Selling Coffee Items")
    plt.xlabel("Units Sold")
    plt.tight_layout()
    if not os.path.exists(top_plot):
        plt.savefig(top_plot)
        print(f"Saved plot: {top_plot}")
    else:
        print(f"Skipped plot: {top_plot} already exists.")
    plt.show()
    plt.close()

    # Cup Size
    sales_by_size = analyzer.get_sales_by_size()
    if not sales_by_size.empty:
        print("\nSALES BY CUP SIZE")
        print(sales_by_size)

        size_plot = f"{visuals_path}sales_by_size.png"
        plt.figure(figsize=(6, 4))
        sns.barplot(x=sales_by_size.index, y=sales_by_size.values, palette="YlGnBu")
        plt.title("Sales by Coffee Cup Size")
        plt.xlabel("Cup Size")
        plt.ylabel("Sales (₹)")
        plt.tight_layout()
        if not os.path.exists(size_plot):
            plt.savefig(size_plot)
            print(f"Saved plot: {size_plot}")
        else:
            print(f"Skipped plot: {size_plot} already exists.")
        plt.show()
        plt.close()

if __name__ == "__main__":
    run()
