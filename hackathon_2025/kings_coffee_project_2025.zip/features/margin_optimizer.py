def run():
    import pandas as pd
    import matplotlib
    matplotlib.use('TkAgg')
    import matplotlib.pyplot as plt
    import seaborn as sns
    import os
    import sys

    sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
    from analysis_modules.margin_analyzer import MarginAnalyzer

    data_path = 'kings_coffee_data/ingredient_prices.csv'
    visuals_path = 'screenshots_plots/'
    outputs_path = 'csv_outputs/'

    os.makedirs(visuals_path, exist_ok=True)
    os.makedirs(outputs_path, exist_ok=True)

    analyzer = MarginAnalyzer(data_path)

    margin_df = analyzer.analyze_margins()
    print("\nMARGIN OPTIMIZATION REPORT")
    print(margin_df)

    margin_csv = f"{outputs_path}margin_report.csv"
    if not os.path.exists(margin_csv):
        margin_df.to_csv(margin_csv, index=False)
        print(f"Saved: {margin_csv}")
    else:
        print(f"Skipped: {margin_csv} already exists.")

    margin_plot = f"{visuals_path}low_margin_items.png"
    low_margin = margin_df.sort_values(by='MarginPercent').head(10)
    plt.figure(figsize=(10, 5))
    sns.barplot(data=low_margin, x='Ingredient', y='MarginPercent', palette='coolwarm')
    plt.title("Bottom 10 Ingredients by Margin Percent")
    plt.xticks(rotation=45, ha='right')
    plt.tight_layout()
    if not os.path.exists(margin_plot):
        plt.savefig(margin_plot)
        print(f"Saved plot: {margin_plot}")
    else:
        print(f"Skipped plot: {margin_plot} already exists.")
    plt.show()
    plt.close()

if __name__ == "__main__":
    run()
