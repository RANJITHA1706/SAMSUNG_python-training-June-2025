import os
import sys

# Add the 'features' directory to the system path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), 'features')))

# Import feature modules dynamically only when needed
def run_sales_analysis():
    from features.sales_analysis import run
    run()

def run_inventory_forecast():
    from features.inventory_forecast import run
    run()

def run_margin_optimization():
    from features.margin_optimizer import run
    run()

def run_customer_analysis():
    from features.customer_analysis import run
    run()

def run_crud_console():
    from features.crud_console import run
    run()

def main():
    while True:
        print("\n=== KING'S COFFEE SHOP ANALYTICS MENU ===")
        print("1. Sales Analysis")
        print("2. Inventory Forecast")
        print("3. Margin Optimization")
        print("4. Customer Behavior Analysis")
        print("5. CRUD Console")
        print("6. Exit")

        choice = input("Select an option (1–6): ").strip()

        if choice == '1':
            print("\nRunning: Sales Analysis")
            run_sales_analysis()

        elif choice == '2':
            print("\nRunning: Inventory Forecast")
            run_inventory_forecast()

        elif choice == '3':
            print("\nRunning: Margin Optimization")
            run_margin_optimization()

        elif choice == '4':
            print("\nRunning: Customer Behavior Analysis")
            run_customer_analysis()

        elif choice == '5':
            print("\nLaunching: CRUD Console")
            run_crud_console()

        elif choice == '6':
            print("\n[Exit] Thank you for using King's Coffee Analytics. Goodbye!")
            break

        else:
            print("[Error] Invalid choice. Please enter a number between 1 and 6.")

if __name__ == "__main__":
    main()
