import pandas as pd

class SalesAnalyzer:
    def __init__(self, sales_data_path):
        """
        Initializes the SalesAnalyzer with sales data from a CSV file.
        """
        self.sales_df = pd.read_csv(sales_data_path, parse_dates=['date'])

    def get_monthly_sales(self):
        """
        Returns total sales grouped by month.
        """
        self.sales_df['month'] = self.sales_df['date'].dt.strftime('%b')
        monthly_sales = self.sales_df.groupby('month')['total_price'].sum().reindex([
            'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
            'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
        ])
        return monthly_sales

    def get_top_selling_items(self, top_n=5):
        """
        Returns top N best-selling items by quantity.
        """
        return self.sales_df.groupby('item')['quantity'].sum().sort_values(ascending=False).head(top_n)

    def get_daily_average_sales(self):
        """
        Returns average daily revenue.
        """
        daily_sales = self.sales_df.groupby('date')['total_price'].sum()
        return daily_sales.mean()

    def get_sales_by_size(self):
        """
        Returns total sales by cup size (if available).
        """
        if 'size' in self.sales_df.columns:
            return self.sales_df.groupby('size')['total_price'].sum().sort_values(ascending=False)
        else:
            return pd.Series(dtype=float)

    def filter_by_date_range(self, start_date, end_date):
        """
        Returns filtered DataFrame for a specific date range.
        """
        mask = (self.sales_df['date'] >= pd.to_datetime(start_date)) & (self.sales_df['date'] <= pd.to_datetime(end_date))
        return self.sales_df[mask]
