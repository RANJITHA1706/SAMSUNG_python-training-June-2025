import pandas as pd

class CustomerBehavior:
    def __init__(self, sales_path):
        self.df = pd.read_csv(sales_path, parse_dates=["visit_date"])
        if 'visit_date' not in self.df.columns:
            print("[Warning] No 'visit_date' column found. Available columns:", list(self.df.columns))

    def get_returning_customers(self):
        returning = self.df.groupby('customer_id').filter(lambda x: len(x) > 1)
        return returning.sort_values(by='visit_date')

    def get_top_spenders(self, n=10):
        top = self.df.groupby('customer_id')['amount'].sum().sort_values(ascending=False).head(n)
        return top.reset_index()

    def get_visit_frequency(self):
        self.df['Month'] = self.df['visit_date'].dt.to_period('M')
        freq = self.df.groupby('Month').size()
        return freq
