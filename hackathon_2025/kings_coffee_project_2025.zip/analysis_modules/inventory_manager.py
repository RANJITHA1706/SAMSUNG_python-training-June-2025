import pandas as pd

class InventoryManager:
    def __init__(self, inventory_path):
        # Load inventory data with expiry and restock dates parsed as datetime
        self.inventory_df = pd.read_csv(inventory_path, parse_dates=['expiry_date', 'restock_date'])

    def get_current_stock_status(self):
        # Return items sorted by current stock in descending order
        if 'CurrentStock' not in self.inventory_df.columns:
            raise ValueError("Missing 'CurrentStock' column in inventory data.")
        return self.inventory_df.sort_values(by='CurrentStock', ascending=False)

    def get_inventory_forecast(self, threshold=50):
        # Return items with stock less than the given threshold
        if 'CurrentStock' not in self.inventory_df.columns:
            raise ValueError("Missing 'CurrentStock' column in inventory data.")
        forecast = self.inventory_df[self.inventory_df["CurrentStock"] < threshold].copy()
        forecast["Status"] = "Low Stock"
        return forecast

    def get_weekly_forecast(self):
        # Return items expiring within the next 7 days
        if 'expiry_date' not in self.inventory_df.columns:
            raise ValueError("Missing 'expiry_date' column in inventory data.")
        today = pd.Timestamp.today()
        upcoming = today + pd.Timedelta(days=7)
        weekly = self.inventory_df[self.inventory_df["expiry_date"].between(today, upcoming)].copy()
        weekly["Status"] = "Expiring Soon"
        return weekly

    def get_at_risk_ingredients(self, threshold=50, within_days=7):
        # Return items that are both low in stock and expiring soon
        if 'CurrentStock' not in self.inventory_df.columns or 'expiry_date' not in self.inventory_df.columns:
            raise ValueError("Missing required columns: 'CurrentStock' or 'expiry_date'.")
        today = pd.Timestamp.today()
        upcoming = today + pd.Timedelta(days=within_days)
        at_risk = self.inventory_df[
            (self.inventory_df['CurrentStock'] < threshold) &
            (self.inventory_df['expiry_date'] <= upcoming)
        ].copy()
        at_risk["Status"] = "At Risk (Low Stock & Expiring Soon)"
        return at_risk
