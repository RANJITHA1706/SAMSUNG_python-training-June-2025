import pandas as pd

class MarginAnalyzer:
    def __init__(self, ingredient_data_path):
        self.data_path = ingredient_data_path
        self.df = pd.read_csv(self.data_path, parse_dates=['last_updated'])
        self._prepare_data()

    def _prepare_data(self):
        # Ensure required columns exist
        required_cols = {'Ingredient', 'CostPrice', 'SellingPrice'}
        if not required_cols.issubset(self.df.columns):
            raise ValueError(f"Missing required columns: {required_cols}")

        # Remove rows with missing data
        self.df.dropna(subset=required_cols, inplace=True)

        # Calculate profit and margin
        self.df["Profit"] = self.df["SellingPrice"] - self.df["CostPrice"]
        self.df["MarginPercent"] = (self.df["Profit"] / self.df["SellingPrice"]) * 100

    def analyze_margins(self):
        # Return top items sorted by margin
        return self.df.sort_values(by="MarginPercent", ascending=False)

    def get_low_margin_items(self, threshold=25):
        # Return items with margin below a threshold
        return self.df[self.df["MarginPercent"] < threshold]

    def get_high_margin_items(self, threshold=50):
        # Return items with margin above a threshold
        return self.df[self.df["MarginPercent"] >= threshold]
